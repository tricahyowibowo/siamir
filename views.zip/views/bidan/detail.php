<div class="content-wrapper" style="padding-left:30px">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-add"></i> Edit bidan
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group" style="padding-left:10px ;">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>bidan/"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $this->session->flashdata('pesan'); ?>
                        </div>
                    </div>

                    <!-- form start -->

                    <form role="form" action="<?php echo base_url() ?>bidan/edit" method="post" id="addnew" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <?php
                                        foreach ($bidan as $s) : ?>
                                            <label for="fname">No Salesman</label>
                                            <input type="text" class="form-control" id="no_salesman" name="no_salesman" value="<?php echo $s->no_salesman; ?>" maxlength="128" readonly>

                                            <label for="fname">Area</label>
                                            <input type="text" class="form-control" id="area_sales" name="area_sales" value="<?php echo $s->area_sales; ?>" maxlength="128" readonly>

                                            <input type="hidden" value="<?php echo $s->id_bidan; ?>" name="id_bidan" id="id_bidan" />

                                            <label for="fname">Nama Bidan</label>
                                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $s->nama_bidan; ?>" maxlength="128">

                                            <label for="fname">kontak</label>
                                            <input type="text" class="form-control" id="kontak" name="kontak" value="<?php echo $s->kontak; ?>" maxlength="128">

                                        <?php endforeach; ?>
                                    </div>

                                </div>
                            </div>

                            <div class="col-md-12 text-right">
                                <button type="submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Edit</button>
                            </div><!-- /.col -->

                        </div><!-- /.box-body -->

                    </form>

                </div>
            </div>
        </div>

    </section>
</div>
</div>
</div>