<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user"></i> List Data bidan
      </h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12 text-right">
          <div class="form-group">
            <a class="btn btn-primary" href="<?php echo base_url(); ?>bidan/tambahbidan"><i class="fa fa-plus"></i> Add New</a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>No. Account</th>
                    <th>SPV</th>
                    <th>Nama bidan</th>
                    <th>Area</th>
                    <th>Kontak</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if (!empty($bidan)) {
                    $no = 1;
                    foreach ($bidan as $s) {
                  ?>

                      <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $s->no_account ?></td>
                        <td><?php echo $s->nama_spv ?></td>
                        <td><?php echo $s->nama_bidan ?></td>
                        <td><?php echo $s->area_sales ?></td>
                        <td><?php echo $s->kontak ?></td>
                        <td>
                          <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'bidan/detail/' . $s->id_bidan ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-sm btn-danger" href="<?php echo base_url() . 'bidan/delete/' . $s->id_bidan ?>"><i class="fa fa-trash"></i></a>

                        </td>
                      </tr>
                  <?php
                    }
                  }
                  ?>
                </tbody>
                <tfoot>
                  <tr>                    
                    <th>No</th>
                    <th>No. Account</th>
                    <th>SPV</th>
                    <th>Nama bidan</th>
                    <th>Area</th>
                    <th>Kontak</th>
                    <th>Aksi</th>
                  </tr>
                </tfoot>
              </table>

            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div>
      </div>


    </section>
  </div>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
  jQuery(document).ready(function() {
    jQuery('ul.pagination li a').click(function(e) {
      e.preventDefault();
      var link = jQuery(this).get(0).href;
      var value = link.substring(link.lastIndexOf('/') + 1);
      jQuery("#searchList").attr("action", baseURL + "ListData/" + value);
      jQuery("#searchList").submit();
    });
  });
</script>