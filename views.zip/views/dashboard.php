<div class="content-wrapper">    
    <section class="content">
          <!-- Content Header (Page header) -->
    <?php
    if($role == ROLE_EMPLOYEE){?>
    <section class="content-header">
      <h2 class="p-2"> Hai, Selamat Datang <b><?php echo $name; ?></b></h2>
    </section>
    <div class="row p-2">
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
              <div class="inner">
                <h3>Customer</h3>
                <h5>Ibu & Anak</h5>
              </div>
              <div class="icon">
                <i class="fa fa-user"></i>
              </div>
              <a href="<?php echo base_url(); ?>TambahCust" class="small-box-footer">Tambah <i class="fa fa-plus"></i></a>
            </div>
          </div><!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
              <h3>Customer</h3>
                <h5>ibu</h5>
              </div>
              <div class="icon">
                <i class="ion ion-clipboard"></i>
              </div>
              <a href="<?php echo base_url(); ?>TambahCustDewasa" class="small-box-footer">Tambah <i class="fa fa-plus"></i></a>
            </div>
          </div><!-- ./col -->
      </div>
    <?php } ?>

    <?php
    if($role == ROLE_ADMIN || $role == ROLE_MANAGER){?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
      <div class="row">
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
              <div class="inner">
                <h3><?php echo $anak?></h3>
                <p>Customer Anak</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="<?php echo base_url(); ?>customer" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div><!-- ./col -->
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
              <h3><?php echo $dewasa?></h3>
                <p>Customer Dewasa</p>
              </div>
              <div class="icon">
                <i class="ion ion-clipboard"></i>
              </div>
              <a href="<?php echo base_url(); ?>DataCustDewasa" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div><!-- ./col -->
      </div>
    <?php } ?>
    </section>
</div>