<style>
    .box{
          box-shadow: 0px 5px 20px 0px #888888;
          border-radius:10px;
    }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    
    <section class="content">
    
    <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url("dashboard"); ?>"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->

                <div class="box box-primary">
                    <section class="content-header">
                        <h1>
                            <i class="fa fa-add"></i> Tambah customer ibu dan anak
                        </h1>
                    </section>
                    <div class="row">
                    <div class="col-md-12">
                        <?php echo $this->session->flashdata('pesan'); ?>
                        </div>
                    </div>
        
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>inputcustomer/savebidan" method="post" id="" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="fname">No Account Bidan</label>
                                            <input type="text" class="form-control required" id="no_account" name="no_account" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Nama Bidan</label>
                                            <input type="text" class="form-control required" id="nama_bidan" name="nama_bidan" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Kontak Bidan</label>
                                            <input type="text" class="form-control required" id="kontak" name="kontak" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Nama SPV</label>
                                            <select id="spv_id" name="spv_id" class="form-control required">
                                                <option value="">--Pilih--</option>
                                                <?php foreach ($spv as $s) : ?>
                                                    <option value="<?= $s->id_spv ?>"><?= $s->nama_spv ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Username</label>
                                            <input type="text" class="form-control required" id="username" name="username" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Area Sales</label>
                                            <input type="text" class="form-control required" id="area_sales" name="area_sales" value="" maxlength="128">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 text-right" >
                                    <button type="submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Tambah</button>
                            </div><!-- /.col -->

                        </div>
                        </div><!-- /.box-body -->

                    </form>
                    
                </div>
            </div>
        </div>
        
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>

