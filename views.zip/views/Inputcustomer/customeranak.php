<style>
    .box {
        box-shadow: 0px 5px 20px 0px #888888;
        border-radius: 10px;
    }

    .content-wrapper {
        background-color: #ffff;
    }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <section class="content">

        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url("dashboard"); ?>"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
                <!-- general form elements -->

                <div class="box box-primary">
                    <section class="content-header">
                        <h1>
                            <i class="fa fa-add"></i> Tambah customer ibu dan anak
                        </h1>
                    </section>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $this->session->flashdata('pesan'); ?>
                        </div>
                    </div>

                    <!-- form start -->

                    <form role="form" action="<?php echo base_url() ?>inputcustomer/save" method="post" id="addCustExternal" role="form" enctype="multipart/form-data">
                        <input type="hidden" value="" name="id_customer" id="id_customer" />
                        <input type="hidden" value="ibu&anak" name="jenis_cust" id="jenis_cust" />
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="fname">Nama Bidan</label>
                                            <input type="text" class="form-control required" id="nama_bidan" name="nama_bidan" value="<?php echo $name ?>" maxlength="128" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Nama Pasien</label>
                                            <input type="text" class="form-control required" id="nama_pasien" name="nama_pasien" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Alamat Pasien</label>
                                            <textarea type="text" class="form-control required" id="alamat_pasien" name="alamat_pasien" value="" rows="5"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Produk susu yang dibeli</label>
                                            <select id="produk_id" name="produk_id" class="form-control required">
                                                <option value="">--Pilih--</option>
                                                <?php foreach ($produk as $p) : ?>
                                                    <option value="<?= $p->id_produk ?>"><?= $p->nama_produk ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">


                                        <div class="form-group">
                                            <label for="fname">Kontak yang bisa dihubungi</label>
                                            <input type="text" class="form-control required digits kontak_pasien" id="kontak_pasien" name="kontak_pasien" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Nama Anak</label>
                                            <input type="text" class="form-control required" id="nama_anak" name="nama_anak" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Produk susu yang dibeli</label>
                                            <select id="produkanak_id" name="produkanak_id" class="form-control required">
                                                <option value="">--Pilih--</option>
                                                <?php foreach ($produkanak as $pa) : ?>
                                                    <option value="<?= $pa->id_produk ?>"><?= $pa->nama_produkanak ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">usia anak (bulan)</label>
                                            <input type="text" class="form-control required" id="usia" name="usia" value="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 text-right">
                                    <button type="submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Tambah</button>
                                </div><!-- /.col -->

                            </div><!-- /.box-body -->

                    </form>

                </div>
            </div>
        </div>

    </section>
</div>
<script src="<?php echo base_url(); ?>assets/js/addCustExternal.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>