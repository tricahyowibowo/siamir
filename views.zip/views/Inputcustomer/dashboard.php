<style>
  body{
    background-image: url("<?php echo base_url(); ?>assets/images/mirotaksm.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
  }

  small{
    font-size: 24px;
  }

  .register-box-body{
    box-shadow: 0px 5px 20px 0px #888888;
    border-radius:10px;
  }
  
  @media only screen and (max-width: 900px ) {
  
    .register-box{
    padding-top:50%;
    }
  }
  
@media only screen and (min-width: 900px ) {
      
  body{
    background-image: url("<?php echo base_url(); ?>assets/images/mirotaksm.jpg");
    background-position: center;
      background-repeat: no-repeat;
      background-size: 100%;
  }

}
</style>
  
  <body>
    <div class="register-box">
    
      <div class="register-box-body">
      <div class="login-logo">
        <a href="#"><b>SI DADAN | <small>PT. Mirota KSM</small></b><br>
        <small><b>Si</b>stem <b>Da</b>ta bi<b>Dan</b></small></a>
      </div><!-- /.login-logo -->

      <div class="row">
            <div class="col-md-12">
                <?php echo $this->session->flashdata('pesan'); ?>
                <?php echo $this->session->flashdata('gagal'); ?>
            </div>
        </div>

        <div class="social-auth-links text-center">
          <a href="AddCustIbu" class="btn btn-block btn-social bg-maroon btn-flat"><i class="fa  fa-female"></i> Data Customer Ibu</a>
          <a href="AddCustIbuAnak" class="btn btn-block btn-social bg-olive btn-flat"><i class="fa  fa-child"></i> Data Customer Ibu dan Anak</a>
        </div>
        <a href="login"> Login</a>
      </div><!-- /.form-box -->
    </div><!-- /.register-box -->

    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url(); ?>assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/plugins/iCheck/icheck.min.js"></script>
  </body>
</html>
