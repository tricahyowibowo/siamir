
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-add"></i> Tambah SPG
      </h1>
    </section>
    
    <section class="content">
    
    <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>spg/"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="row">
                    <div class="col-md-12">
                        <?php echo $this->session->flashdata('pesan'); ?>
                        </div>
                    </div>
        
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>spg/save" method="post" id="addnew" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="fname">Nama</label>
                                        <input type="text" class="form-control" id="nama" name="nama" value="" maxlength="128">
                                        <input type="hidden" value="" name="id_spg" id="id_spg" />    
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="col-md-12 text-right" >
                                    <button type="submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Tambah</button>
                                </div><!-- /.col -->

                        </div><!-- /.box-body -->

                    </form>
                    
                </div>
            </div>
        </div>
        
    </section>
</div>
</div>
</div>
