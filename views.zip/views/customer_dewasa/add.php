<style>
    .box {
        box-shadow: 0px 5px 20px 0px #888888;
        border-radius: 10px;
    }

    .content-wrapper {
        background-color: #ffff;
    }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->


    <section class="content">

        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url("dashboard"); ?>"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- left column -->
            <div class="col-md-6">
                <!-- general form elements -->

                <div class="box box-primary">
                    <section class="content-header">
                        <h1>
                            <i class="fa fa-add"></i> Tambah customer ibu
                        </h1>
                    </section>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $this->session->flashdata('pesan'); ?>
                        </div>
                    </div>

                    <!-- form start -->

                    <form role="form" action="<?php echo base_url() ?>customer/savedewasa" method="post" id="addCust" role="form" enctype="multipart/form-data">
                        <input type="hidden" value="" name="id_customer" id="id_customer" />
                        <input type="hidden" value="ibu" name="jenis_cust" id="jenis_cust" />
                        <input type="hidden" value="" name="produkanak_id" id="produkanak_id" />
                        <input type="hidden" value="" name="nama_anak" id="nama_anak" />
                        <input type="hidden" value="" name="produkanak_sebelum" id="produkanak_sebelum" />
                        <input type="hidden" value="" name="ket2" id="ket2" />
                        <input type="hidden" value="" name="usia" id="usia" />
                        

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="fname">Nama Bidan</label>
                                            <select id="bidan_id" name="bidan_id" class="form-control required">
                                                <option value="">--Pilih--</option>
                                                <?php foreach ($bidan as $b) : ?>
                                                    <option value="<?= $b->id_bidan ?>"><?= $b->nama_bidan ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="fname">Nama Pasien</label>
                                            <input type="text" class="form-control required" id="nama_pasien" name="nama_pasien" value="" maxlength="128">
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Alamat Pasien</label>
                                            <textarea type="text" class="form-control required" id="alamat_pasien" name="alamat_pasien" value="" rows="5"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="fname">Produk susu yang dibeli</label>
                                            <select id="produk_id" name="produk_id" class="form-control required">
                                                <option value="">--Pilih--</option>
                                                <?php foreach ($produk as $p) : ?>
                                                    <option value="<?= $p->id_produk ?>"><?= $p->nama_produk ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="produk_sebelum">Produk susu sebelumnya</label>
                                            <select id="produk_sebelum" name="produk_sebelum" class="form-control required">
                                                    <option value="" readonly>--Pilih--</option>
                                                    <option value="Lactona">Lactona Ibu</option>
                                                    <option value="Prenagen">Prenagen</option>
                                                    <option value="Others">Others</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="fname">*Produk Lain<small> (jika memilih others)</small> </label>
                                            <input type="text" class="form-control" id="ket1" name="ket1" value="" placeholder="jika tidak ada di antara kedua pilihan">
                                        </div>

                                        <div class="form-group">
                                            <label for="fname">Kontak yang bisa dihubungi</label>
                                            <input type="text" class="form-control required digits kontak_pasien" id="kontak_pasien" name="kontak_pasien" value="" maxlength="128">
                                        </div>

                                    </div>

                                </div>
                                <div class="col-md-12 text-right">
                                    <button type="submit" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Tambah</button>
                                </div><!-- /.col -->

                                

                            </div><!-- /.box-body -->

                    </form>

                </div>
            </div>
        </div>

    </section>
</div>
<script src="<?php echo base_url(); ?>assets/js/addCustExternal.js" type="text/javascript"></script>