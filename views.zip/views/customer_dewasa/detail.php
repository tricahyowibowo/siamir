
<div class="content-wrapper">
<?php    
foreach ($customer as $c):?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-add"></i> Tambah SPG
      </h1>
    </section>

    <div class="box">
    <div class="box-header with-border">
        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
        </div>
    </div>
    <div class="box-body">

    <div class="row">
            <div class="col-xs-12    text-left">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>customer/"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
        </div>
            <div class="col-sm-6">
                <table class="table w-100">
                    <tr>
                        <th>Nama SPG</th>
                        <td><?php echo $c->nama ?></td>
                    </tr>
                    <tr>
                        <th>Nama Outlet</th>
                        <td><?php echo $c->nama_outlet ?></td>
                    </tr>
                    <tr>
                        <th>Produk yang dibeli</th>
                        <td><?php echo $c->nama_produk ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="table-responsive px-4 pb-3 col-md-12" style="border: 100">
        <table id="detail_jwb" class="w-100 table table-striped table-hover" width="200px">
        <thead>
            <tr>
                <th>Nama Customer</th>
                <th>Alamat</th>
                <th>No. HP</th>
                <th>Jenis Kontak</th>
                <th>Produk Sebelumnya</th>
                <th>No.KTP</th>
            </tr>        
        </thead>
        <tbody>
        <tr>
            <td><?php echo $c->nama_cust ?></td>
            <td><?php echo $c->alamat ?></td>
            <td><?php echo $c->kontak ?></td>
            <td><?php echo $c->no_hp ?></td>
            <td><?php echo $c->produk_sblm ?></td>
            <td><?php echo $c->no_ktp ?></td>
        </tr>
        </tbody>
        </table>
    </div>

<section class="content">       
<div class="row">
    <!-- left column -->
    <div class="col-md-4">
      <!-- general form elements -->
        <div class="box">
            <div class="box-header">
                <h4> Bukti Struk</h4>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">                                
                    <img src="<?php echo base_url() . 'assets/foto_customer/'.$c->bukti_struk;?>" alt="<?php echo  $c->bukti_struk; ?>" width="300" height="200"></img>

                    </div>
                </div>
            </div><!-- /.box-body -->
        </div>
    </div>
</div>
</section>
<?php endforeach; ?>
</div>
    

