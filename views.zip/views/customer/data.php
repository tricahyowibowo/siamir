<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>List Data Customer </h1>
        
      
    </section>
    <!-- Main content -->
    <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
          <div class="box-header">
          <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>TambahCust"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
          </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Bidan</th>
                  <th>Nama Produk</th>
                  <th>Produk Sebelum</th>
                  <th>produk</th>
                  <th>Nama Pasien</th>
                  <th>Alamat Pasien</th>
                  <th>Kontak</th>
                  <th>Nama Anak</th>
                  <th>Nama Produk</th>
                  <th>Produk Sebelum</th>
                  <th>Produk</th>
                  <th>Usia</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    if(!empty($customer))
                    {
                        $no = 1;
                        foreach($customer as $c)
                        {
                    ?>
                 <tr>
                      <td><?php echo $no++ ?></td>
                      <td><?php echo $c->nama_bidan ?></td>
                      <td><?php echo $c->nama_produk ?></td>
                      <td><?php echo $c->produk_sebelum ?></td>
                      <td><?php echo $c->ket1 ?></td>
                      <td><?php echo $c->nama_pasien ?></td>
                      <td><?php echo $c->alamat_pasien ?></td>
                      <td><?php echo $c->kontak_pasien ?></td>
                      <td><?php echo $c->nama_anak ?></td>
                      <td><?php echo $c->nama_produkanak ?></td>
                      <td><?php echo $c->produkanak_sebelum ?></td>
                      <td><?php echo $c->ket2 ?></td>
                      <td><?php echo $c->usia ?> Bulan</td>

<!-- 
                      <td>
                      <a class="btn btn-sm btn-default" href="<?php echo base_url().'customer/detail/'.$c->id_customer ?>"><i class="fa fa-pencil"></i></a>
                      </td> -->
                      <!-- <td>
                        <?php
                        $var=$c->status;
                        if(is_null($var)) { ?>
                        <form action="<?php echo base_url(); ?>customer/aksi" method="post">
                          <input type="hidden" value="<?php echo $c->id_customer ?>" name="id_customer" id="id_customer" />
                          <button class="btn btn-sm btn-info" name="status" type="submit" value="Y"><i class="fa fa-plus"></i></button>
                          <button class="btn btn-sm btn-warning" name="status" type="submit" value="R"><i class="fa fa-minus"></i></button>
                          <button class="btn btn-sm btn-danger" name="status" type="submit" value="N"><i class="fa fa-close"></i></button>
                        </form>
                        <?php } elseif ($var == "R") { ?>
                          <form action="<?php echo base_url(); ?>customer/aksi" method="post">
                          <input type="hidden" value="<?php echo $c->id_customer ?>" name="id_customer" id="id_customer" />
                          <span class="label label-warning">Pending</span>
                          <button class="btn btn-sm btn-info" name="status" type="submit" value="Y"><i class="fa fa-plus"></i></button>
                          <button class="btn btn-sm btn-danger" name="status" type="submit" value="N"><i class="fa fa-close"></i></button>
                          </form>
                        <?php } elseif ($var == "Y"){ ?>
                          <span class="label label-success">verified</span>
                        <?php } elseif ($var == "N"){ ?>
                          <span class="label label-danger">not verified</span>
                        <?php } ?>

                      </td> -->
                    </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
                <tfoot>
                <tr>
                <th>No</th>
                  <th>Nama Bidan</th>
                  <th>Nama Produk</th>
                  <th>Produk Sebelum</th>
                  <th>produk</th>
                  <th>Nama Pasien</th>
                  <th>Alamat Pasien</th>
                  <th>Kontak</th>
                  <th>Nama Anak</th>
                  <th>Nama Produk</th>
                  <th>Produk Sebelum</th>
                  <th>Produk</th>
                  <th>Usia</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>


