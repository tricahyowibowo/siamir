<div class="content-wrapper">
<div class="container-fluid">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user"></i> List Data spv
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>spv/tambahspv"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
              <div class="box">
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama SPV</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if(!empty($spv))
                    {
                        $no = 1;
                        foreach($spv as $s)
                        {
                    ?>

                    <tr>
                      <td><?php echo $no++ ?></td>
                      <td><?php echo $s->nama_spv ?></td>
                      <td>
					  	          <a class="btn btn-sm btn-info" href="<?php echo base_url().'spv/detail/'.$s->id_spv ?>"><i class="fa fa-pencil"></i></a>
                        <a class="btn btn-sm btn-danger" href="<?php echo base_url().'spv/delete/'.$s->id_spv ?>"><i class="fa fa-trash"></i></a>
 
                    </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                    </tbody>
                    <tfoot>
                <tr>
                <th>No</th>
                      <th>Nama spv</th>
                      <th>Aksi</th>
                </tr>
                </tfoot>
                  </table>
                  
                  </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
        </div>


    </section>
</div>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "ListData/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>